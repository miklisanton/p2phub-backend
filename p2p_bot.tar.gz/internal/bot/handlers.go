package bot

func (bot *Bot) handleStart(chatID int64) {

}
